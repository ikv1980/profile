from django.apps import AppConfig


class DiplomConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'diplom'
